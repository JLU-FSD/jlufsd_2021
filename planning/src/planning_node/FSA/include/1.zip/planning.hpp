#ifndef PLANNING_HPP
#define PLANNING_HPP
#include "ros/ros.h"

#include "auto_msgs/Map.h"
#include "auto_msgs/CarState.h"
#include "auto_msgs/CarStateDt.h"
#include <nav_msgs/Path.h>

#include <Eigen/Dense>
#include <math.h>

#include "planning_common.h"
#include "longitudinal_module.h"
#include "smoother_module.h"

class Planning {

 public:
    // Constructor
    Planning(ros::NodeHandle& nh);

    // Getters
    nav_msgs::Path          visTrajectory();
    nav_msgs::Path          visCenterLine();
    nav_msgs::Path          visLeftBoundry();
    nav_msgs::Path          visRightBoundry();

    // Setters
    void setMaxSpeed(double &max_speed);

    //检测程序
    bool roadInfoCheckOK();
    void lapRecord();

    /**
     *  creates the trajectory
     */
    
    void createCenterLine();
    // void createRoadWidth(const auto_msgs::Map &map, planning::Path &path);
    // void createMaxSpeed(planning::Path &path);
    void createTrajectory();
    void expandGlobalMap();
    void createLocalMap();
    void createLocalDenseMap();
    void createGlobalDenseMap();

    /**
     * calls the other functions in the right order
     */
    void runAlgorithm();

//  private:
    planning::Vehicle               state_;
    planning::Road                  perceived_road_;
    planning::Road                  reserve_road_;
    planning::Road                  local_road_;
    planning::Road                  global_road_;
    planning::Path                  trajectory_;

    planning::Vehicle               start_state_;
    bool                            in_start_state_ = true;//处于起点附近为真
    bool                            start_flag_ = true;//检测到橙色桩桶时为真
    bool                            start_state_recorded_ = false;
    int                             lap = 0;

    double                          max_speed_;

    // PolynomialSpline                spline_;
    // PurePursuitSmoother             pure_pursuit_smoother_;
    // StanleySmoother                 stanley_smoother_;
    // LqrSmoother                     lqr_smoother_;
    // Rotate3orderSmoother            rotate_3order_smoother_;
    // IterativePolynomialSmoother     iterative_polynomial_smoother_;

    // MinCurOptimizer                 min_cur_optimizer;

    // MaxVelocityGenerator            vGenerator;
};

#endif //PLANNING_HPP
