#ifndef PLANNING_HANDLE_HPP
#define PLANNING_HANDLE_HPP

#include "nav_msgs/Path.h"
#include "geometry_msgs/PointStamped.h"
#include "sensor_msgs/PointCloud2.h"
#include "auto_msgs/Map.h"
#include "auto_msgs/CarState.h"
#include "auto_msgs/CarStateDt.h"
// #include "auto_msgs/ControlCommand.h"

#include <pcl/io/pcd_io.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/search/kdtree.h>
#include <pcl/search/impl/kdtree.hpp>

#include "planning.hpp"
#include "common/planning_math_tool.h"
#include "trajectory.h"
#include "road.h"
#include "vehicle.h"

class PlanningHandle {

 public:
  // Constructor
  explicit PlanningHandle(ros::NodeHandle &nodeHandle);

//  // Getters
  int getNodeRate() const { return node_rate_; };

  // Methods
  void loadParameters();
  void subscribeToTopics();
  void publishToTopics();
  void run();
  void sendBountry();
  void sendTrajectory();
  void sendCenterLine();
  void sendSimControl();  
  void sendConePointCloud();
  //最后一项0代表向左，1代表向右
  void findNearestPoint(std::vector<auto_msgs::Cone> &cone_clean, 
                                        std::vector<auto_msgs::Cone> &cone_set, 
                                        double & x, double & y, double & yaw, 
                                        int direction);

 private:
  ros::NodeHandle nodeHandle_;
  
  ros::Publisher trajectoryPublisher_;
  ros::Publisher centerLinePublisher_;
  ros::Publisher controlPublisher_;
  ros::Publisher followPointPublisher_;
  ros::Publisher yellowConePublisher_;
  ros::Publisher blueConePublisher_;
  ros::Publisher leftBoundryPublisher_;
  ros::Publisher rightBoundryPublisher_;

  ros::Subscriber slamMapSubscriber_;
  ros::Subscriber slamStateSubscriber_;
  ros::Subscriber velocityEstimateSubscriber_;

  void velocityEstimateCallback(const auto_msgs::CarStateDt &velocity);
  void slamMapCallback(const auto_msgs::Map &map);
  void slamStateCallback(const auto_msgs::CarState &state);

  std::string velocity_estimate_topic_name_;
  std::string slam_map_topic_name_;
  std::string slam_state_topic_name_;
  std::string trajectory_topic_name_;
  std::string center_line_topic_name_;
  std::string control_topic_name_;
  std::string yellow_point_cloud_name_;
  std::string blue_point_cloud_name_;
  std::string left_boundry_topic_name_;
  std::string right_boundry_topic_name_;
  std::string follow_point_topic_name_;
  

  int node_rate_;
  double max_speed_;
  
  Planning planning_;

  nav_msgs::Path trajectory_;
  nav_msgs::Path center_line_;
  nav_msgs::Path left_boundry_;
  nav_msgs::Path right_boundry_;
  geometry_msgs::PointStamped follow_point_;
  

  auto_msgs::Map map_;
};
#endif //PLANNING_HANDLE_HPP