#include "vio_record_node.h"
#include "ros/ros.h"
#include "can_config_data_path.h"
#include <yaml-cpp/yaml.h>
int main(int argc, char **argv)
{
	std::string can_node_yaml_file_name = can_config_data_path + "can_node.yaml";
	ros::init(argc, argv, "can");
	ROS_INFO("INIT SUSCESS");
	VioRecordNode node(can_node_yaml_file_name);
	ROS_INFO("NODE INIT");

	while (1)
	{
		node.step();
	}

	return 0;
}